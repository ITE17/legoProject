package Data;

public class LoginSampleException extends Exception {

    public LoginSampleException(String msg) {
        super(msg);
    }
    

}
