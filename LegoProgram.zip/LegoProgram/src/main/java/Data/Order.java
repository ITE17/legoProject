package Data;

import View.Calculator;

/**
 *
 * @author Ludvig
 */
public class Order {
    
    private int userid;
    private int orderid;
    private int height;
    private int width;
    private int length;
    private int status;
    
    public Calculator calculator = new Calculator();
    
    public Order(int length, int width, int height){
        this.height = height;
        this.width = width;
        this.length = length;
        calculator.setCalculator(length, width, height);
    }

    public void setOrderId(int orderid) {
        this.orderid = orderid;
    }
    
    public int getOrderId() {return orderid;}
    
    public void setUserId(int userid) {
        this.userid = userid;
    }
    
    public int getUserId() {return userid;}

    public void setStatus(int sent) {
        this.status = sent;
    }

    public int getStatus() {
        return status;
    }

    public int getHeight() {return height;}

    public int getWidth() {return width;}

    public int getLength() {return length;}

    @Override
    public String toString() {
        return "Order{" + "userid=" + userid + ", height=" + height + ", width=" + width + ", length=" + length + ", measurements " + (height*(length+width)) + '}';
    }    
}
