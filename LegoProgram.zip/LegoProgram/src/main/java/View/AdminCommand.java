/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Control.UserManager;
import Data.Order;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Ludvig
 */
public class AdminCommand implements Command {
    private String target;

    AdminCommand(String target) {
        this.target = target;
    }

    @Override
    public String execute(HttpServletRequest request, UserManager manager) throws CommandException {
        HttpSession session = request.getSession();
        
        ArrayList<Order> orders = null;
        
        try {
            orders = manager.getAllOrders();
        } catch (Exception ex) {
            Logger.getLogger(ListCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        session.setAttribute("orders", orders);
        return target;
    }
}
