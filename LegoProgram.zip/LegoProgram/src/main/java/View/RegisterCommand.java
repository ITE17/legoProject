/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Control.UserManager;
import Data.User;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Ludvig
 */
public class RegisterCommand implements Command{
    
    private String target;

    RegisterCommand(String target) {
        this.target = target;
    }  

    @Override
    public String execute(HttpServletRequest request, UserManager manager) throws CommandException {
        String name = request.getParameter( "name" );
        String password1 = request.getParameter( "password1" );
        String password2 = request.getParameter( "password2" );
        
        User user = null;
        
        if ( password1.equals( password2 ) ) {
            user = new User(name, password1, "customer");
            
            try {
            manager.createUser(user);
            } catch (Exception ex) {
            Logger.getLogger(LoginCommand.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            HttpSession session = request.getSession(); 
            session.setAttribute( "user", user );
            
            return target;
        } else {
            throw new CommandException( "the two passwords did not match" );
        }
        }
}
