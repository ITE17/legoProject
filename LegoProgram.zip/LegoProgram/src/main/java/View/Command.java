package View;

import Control.UserManager;
import javax.servlet.http.HttpServletRequest;


public interface Command {
  String execute(
      HttpServletRequest request,
      UserManager manager
      ) throws CommandException;
  }
