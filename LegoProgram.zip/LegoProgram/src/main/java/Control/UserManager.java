/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Data.Order;
import Data.User;
import Data.UserMapper;
import java.util.ArrayList;

/**
 *
 * @author Ludvig
 */
public class UserManager {
    
    private static UserMapper mapper;      
    
    public void setMapper(UserMapper mapper){
        UserManager.mapper = mapper;
    }
    
    public void createUser( User user ) throws Exception{
        mapper.createUser(user);
    }
    
    public static UserMapper getMap(){
        return mapper;
    } 
    
    public User getUser(String name, String password) throws Exception{
        User us = mapper.getUser(name, password);
        return us;
    }
    
    public void createOrder(User user, Order order) throws Exception{
        mapper.createOrder(user, order);
    }
    
    public ArrayList<Order> getOrders(User user) throws Exception {
        return mapper.getOrders(user);
    }
    
    public ArrayList<Order> getAllOrders() throws Exception {
        return mapper.getAllOrders();
    }
}
