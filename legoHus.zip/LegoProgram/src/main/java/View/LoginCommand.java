/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Control.UserManager;
import Data.User;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.sql.SQLException;
import toBeRemoved.PetManager;

/**
 *
 * @author Ludvig
 */
public class LoginCommand implements Command {

    private String target;

    LoginCommand(String target) {
        this.target = target;
    }  

    @Override
    public String execute(HttpServletRequest request, UserManager manager) throws CommandException {
        String name = request.getParameter( "name" );
        String password = request.getParameter( "password" );
        
        User user = null;
        
        try {
            user = manager.getUser(name, password);
        } catch (Exception ex) {
            Logger.getLogger(LoginCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        HttpSession session = request.getSession();
        session.setAttribute("user", user);
        
        return target;
    }
}
