package View;

import java.util.HashMap;
import java.util.Map;

public class CommandFactory {
  private static CommandFactory instance = null;
  private final Map<String, Command> commands = new HashMap();
  
  private CommandFactory() {
    Command backToMain = new TargetCommand("main.jsp");
    commands.put("list", new ListCommand("list.jsp"));
    commands.put("back", backToMain); //if command is null, sent back to 
    commands.put("cancel", backToMain);
    commands.put("login", new LoginCommand("user.jsp"));
    commands.put("order", new OrderCommand("order.jsp"));
    commands.put("register", new RegisterCommand("user.jsp"));
    }
  
  public static synchronized Command commandFrom(String key) {
    if (key == null) key = "back";
    if (instance == null) instance = new CommandFactory();
    return instance.commands.get(key);
    }
  
  }
