package View;

import Control.UserManager;
import Data.UserMapper;
import javax.servlet.http.HttpServletRequest;
//import toBeRemoved.PetManager;


public interface Command {
  String execute(
      HttpServletRequest request,
      UserManager manager
      ) throws CommandException;
  }
