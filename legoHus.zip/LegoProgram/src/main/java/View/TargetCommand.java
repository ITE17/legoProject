package View;

import Control.UserManager;
import javax.servlet.http.HttpServletRequest;
import toBeRemoved.PetManager;

class TargetCommand implements Command {
    private final String target;

    TargetCommand(String target) {
        this.target = target;
    }
  
    @Override
    public String execute(HttpServletRequest request, UserManager manager) {
        return target;
    }
}
