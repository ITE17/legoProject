package View;

import Control.UserManager;
import Data.Order;
import Data.User;
import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import toBeRemoved.Pet;
import toBeRemoved.PetManager;

class ListCommand implements Command {
    private String target;

    ListCommand(String target) {
        this.target = target;
    }

    @Override
    public String execute(HttpServletRequest request, UserManager manager) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        ArrayList<Order> orders = null;
        
        try {
            orders = manager.getOrders(user);
        } catch (Exception ex) {
            Logger.getLogger(ListCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        session.setAttribute("orders", orders);
        return target;
    }
}
