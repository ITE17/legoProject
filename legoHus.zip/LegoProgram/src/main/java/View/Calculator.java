/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

/**
 *
 * @author Ludvig
 */
public final class Calculator {
    
    private int height;
    
    private int numberOf4Length;
    private int numberOf2Length;
    private int numberOf1Length;
    
    private int numberOf4Width;
    private int numberOf2Width;
    private int numberOf1Width;
    
    public int numberOf4;
    public int numberOf2;
    public int numberOf1;
    
    public void setCalculator(int length, int width, int height){
        this.height = height;
        length(length);
        width(width);
        numberOf4 = numberOf4Length * height + numberOf4Width * height;
        numberOf2 = numberOf2Length * height + numberOf2Width * height;
        numberOf1 = numberOf1Length * height + numberOf1Width * height;
    }
    
    public int getNumberOf4Length(){ 
        return numberOf4Length;
    }
    
    public int getNumberOf2Length(){
        return numberOf2Length;
    }
    
    public int getNumberOf1Length(){
        return numberOf1Length;
    }
    
    public int getNumberOf4Width(){ 
        return numberOf4Width;
    }
    
    public int getNumberOf2Width(){
        return numberOf2Width;
    }
    
    public int getNumberOf1Width(){
        return numberOf1Width;
    }

    public int getNumberOf4() {
        return numberOf4;
    }

    public int getNumberOf2() {
        return numberOf2;
    }

    public int getNumberOf1() {
        return numberOf1;
    }
    
    public void length(int length){
        int left2 = 0;
        int left1 = 0;
        
        int number2 = 0;
        int number1 = 0;
        
        int left4 = length%4;
        int number4 = (length-left4)/4;
        
        if(left4 != 0){
            left2 = left4%2;
            number2 = (left4-left2)/2;
        }
        
        if(left2 != 0){
            left1 = left2/1;
        }
        
        numberOf4Length = number4*2;
        numberOf2Length = number2*2;
        numberOf1Length = left1*2;
    }
    
    public void width(int width){
        width = width - 4;
        
        int left2 = 0;
        int left1 = 0;
        
        int number2 = 0;
        int number1 = 0;
        
        int left4 = width%4;
        int number4 = (width-left4)/4;
        
        if(left4 != 0){
            left2 = left4%2;
            number2 = (left4-left2)/2;
        }
        
        if(left2 != 0){
            left1 = left2/1;
        }
        
        numberOf4Width = number4*2;
        numberOf2Width = number2*2;
        numberOf1Width = left1*2;
    }

    public static void main(String[] args){
        Calculator calc = new Calculator();
        
        calc.setCalculator(12,21,9);
        
        System.out.println(calc.getNumberOf4());
        System.out.println(calc.getNumberOf2());
        System.out.println(calc.getNumberOf1());
    }
}
