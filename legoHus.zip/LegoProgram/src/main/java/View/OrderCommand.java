/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Control.UserManager;
import Data.Order;
import Data.User;
import static java.lang.Integer.parseInt;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Ludvig
 */
public class OrderCommand implements Command{
    
    private String target;

    OrderCommand(String target) {
        this.target = target;
    }  

    @Override
    public String execute(HttpServletRequest request, UserManager manager) throws CommandException {
        int height = parseInt(request.getParameter("height"));
        int width = parseInt(request.getParameter("width"));
        int length = parseInt(request.getParameter("length"));
        
        Order order = new Order(length, width, height);
        
        HttpSession session = request.getSession();
        
        User user = (User) session.getAttribute("user");
        
        try {
            manager.createOrder(user, order);
        } catch (Exception ex) {
            Logger.getLogger(OrderCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        session.setAttribute("order", order);
        
        return target;
    }   
}
