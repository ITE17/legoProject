/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Ludvig
 */
public class DBUserMapper extends UserMapper{
    
    private static DBUserMapper instance = null;
    
    public synchronized static DBUserMapper getInstance() {
        if (instance == null) instance = new DBUserMapper();
        return instance;
    }

    @Override
    public User getUser(String name, String password) throws Exception {        
        try {
            Connection con = Connector.connection();
            
            String SQL = "SELECT id, role FROM User "
                    + "WHERE name=? AND password=?";
            PreparedStatement ps = con.prepareStatement( SQL );
            ps.setString( 1, name );
            ps.setString( 2, password );
            ResultSet rs = ps.executeQuery();
            if ( rs.next() ) {
                String role = rs.getString( "role" );
                int id = rs.getInt( "id" );
                User user = new User( name, password, role );
                user.setId( id );
                return user;
            } else {
                throw new Exception( "Could not validate user" );//here the exception
            }
        } catch ( ClassNotFoundException | SQLException ex ) {
            throw new Exception(ex.getMessage());
        }
    }
    
    @Override
    public void createUser( User user ) throws Exception {
        try {
            Connection con = Connector.connection(); //får singleton connection
            String SQL = "INSERT INTO user (name, password, role) VALUES (?, ?, ?)"; //statement til SQL, 
                                                                                   //der sættes værdier på spørgsmålstegnene
            PreparedStatement ps = con.prepareStatement( SQL, Statement.RETURN_GENERATED_KEYS ); //et prækompileret SQl kald 
            ps.setString( 1, user.getName() ); //sets the user details
            ps.setString( 2, user.getPassword() ); 
            ps.setString( 3, user.getRole() );
            ps.executeUpdate(); //executes update
            ResultSet ids = ps.getGeneratedKeys(); //giver resultset tilbage, som er en pointer til database positionen
            ids.next();  //goes to the next position
            int id = ids.getInt( 1 ); //gives column row 
            user.setId( id ); //sets it as id for the user
        } catch ( SQLException | ClassNotFoundException ex ) {
            throw new Exception( ex.getMessage() );
        }
    }
    
    @Override
    public void createOrder( User user, Order order ) throws Exception {
        try {
            Connection con = Connector.connection(); //får singleton connection
            String SQL = "INSERT INTO website.order (length, width, height, userid) VALUES (?, ?, ?, ?)"; //statement til SQL, 
                                                                                   //der sættes værdier på spørgsmålstegnene
            PreparedStatement ps = con.prepareStatement( SQL, Statement.RETURN_GENERATED_KEYS ); //et prækompileret SQl kald 
            ps.setInt( 1, order.getLength() ); //sets the user details
            ps.setInt( 2, order.getWidth() ); 
            ps.setInt( 3, order.getHeight() );
            ps.setInt( 4, user.getId() );
            ps.executeUpdate(); //executes update
            ResultSet ids = ps.getGeneratedKeys(); //giver resultset tilbage, som er en pointer til database positionen
            ids.next();  //goes to the next position
            int id = ids.getInt( 1 ); //gives column row 
            order.setUserId( id ); //sets it as id for the user
        } catch ( SQLException | ClassNotFoundException ex ) {
            throw new Exception( ex.getMessage() );
        }
    }
    
    @Override
    public ArrayList<Order> getOrders(User user) throws Exception {    
        
        ArrayList<Order> orders = new ArrayList();
        
        try {
            Connection con = Connector.connection();
            
            String SQL = "SELECT * FROM website.order "
                    + "WHERE userid=?;";
            PreparedStatement ps = con.prepareStatement( SQL );
            ps.setInt( 1, user.getId() );
            ResultSet rs = ps.executeQuery();
            while ( rs.next() ) {
                int length = rs.getInt("length");
                int width = rs.getInt("width");
                int height = rs.getInt("height");
                int id = rs.getInt( "userid" );
                Order order = new Order(height, width, length);
                order.setUserId( id );
                orders.add(order);
            }
        } catch ( ClassNotFoundException | SQLException ex ) {
            throw new Exception(ex.getMessage());
        }
        
        return orders;
    }
}
