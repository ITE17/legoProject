/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Ludvig
 */
public abstract class UserMapper {
    
    public static UserMapper instance() throws ClassNotFoundException, SQLException{
        return (UserMapper) DBUserMapper.getInstance();
    }
    
    public abstract User getUser(String name, String password)throws Exception;
    
    public abstract void createUser(User user) throws Exception;
    
    public abstract void createOrder(User user, Order order) throws Exception;
    
    public abstract ArrayList<Order> getOrders(User user)throws Exception;
}
