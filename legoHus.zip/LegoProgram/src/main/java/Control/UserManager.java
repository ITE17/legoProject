/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Data.DBUserMapper;
import Data.Order;
import Data.User;
import Data.UserMapper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Ludvig
 */
public class UserManager {
    
    private static UserMapper mapper;      
    
//    public UserManager() throws ClassNotFoundException, SQLException{
//        UserManager.mapper = UserMapper.instance();
//    }
    //UserMapper object mapper is equal to a DBUserMapper object
    
    public void setMapper(UserMapper mapper){
        UserManager.mapper = mapper;
    }
    
    public void createUser( User user ) throws Exception{
        mapper.createUser(user);
    }
    
    public static UserMapper getMap(){
        return mapper;
    } 
    
    public User getUser(String name, String password) throws Exception{
        User us = mapper.getUser(name, password);
        return us;
    }
    
    public void createOrder(User user, Order order) throws Exception{
        mapper.createOrder(user, order);
    }
    
    public ArrayList<Order> getOrders(User user) throws Exception {
        return mapper.getOrders(user);
    }
    
    public static void main(String[] args) throws ClassNotFoundException, SQLException, Exception{
        UserMapper mapper = DBUserMapper.getInstance();
        UserManager usma = new UserManager();   
        usma.setMapper(mapper);
        
//        User user = usma.getUser("ken@somewhere.com", "kensen");  
//        System.out.println(user.getName());

        Order order = new Order(23, 9, 7);
        System.out.println(order.calculator.getNumberOf4());  
        System.out.println(order.calculator.getNumberOf2());  
        System.out.println(order.calculator.getNumberOf1());  
        System.out.println(order.calculator.getNumberOf4Length());  
    }
}
