package toBeRemoved;

import java.util.Collection;

public abstract class PetMapper {
  
  public static PetMapper instance() {
    return HashPetMapper.getInstance();
    }
  
  public abstract Collection<Pet> list();
  
  public abstract Pet find(int id); //you have to make this method, maybe?
  
  public abstract Pet save(Pet pet);
  
  }
